<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('applications', function (Blueprint $table) {
            $table->dropForeign(['app_category_id']);
            $table->foreignId('app_category_id')
                ->nullable()
                ->change()
                ->constrained('app_categories')
                ->nullOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('applications', function (Blueprint $table) {
            $table->dropForeign(['app_category_id']);
            $table->foreignId('app_category_id')
                ->nullable(false)
                ->change()
                ->constrained('app_categories')
                ->restrictOnDelete();
        });
    }
};
