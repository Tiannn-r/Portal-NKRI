<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->foreignId('department_id')
                ->nullable()
                ->after('password')
                ->constrained('departments')
                ->nullOnDelete();
            $table->boolean('is_active')
                ->default(true)
                ->after('department_id');

            $table->index(['department_id', 'is_active']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropIndex(['department_id', 'is_active']);
            $table->dropForeign(['department_id']);
            $table->dropColumn(['department_id', 'is_active']);
        });
    }
};
