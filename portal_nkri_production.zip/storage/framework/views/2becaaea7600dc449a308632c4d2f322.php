<div <?php echo e($attributes->class(['fi-dropdown-list p-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\ibnhu\Desktop\Muhamad Ibnhu\Portal NKRI\vendor\filament\support\resources\views/components/dropdown/list/index.blade.php ENDPATH**/ ?>